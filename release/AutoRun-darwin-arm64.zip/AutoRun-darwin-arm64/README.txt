AutoRun local package

Windows:
  Double click start-autorun.bat.

macOS:
  Double click start-autorun.command, or run ./start-autorun.sh.

Linux:
  Run ./start-autorun.sh.

The app opens http://localhost:8080 and stores no cloud deployment settings.
Phone/password login is entered in the web page.

You can also run the autorun binary directly. It starts the local server and
opens the browser automatically.
