#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
PORT="${PORT:-8080}"
export PORT
./autorun > autorun.log 2>&1 &
SERVER_PID=$!
cleanup() {
  kill "$SERVER_PID" >/dev/null 2>&1 || true
}
trap cleanup EXIT INT TERM
echo "AutoRun is running at http://localhost:${PORT}"
echo "Press Ctrl+C to stop."
wait "$SERVER_PID"
