@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
if "%PORT%"=="" set PORT=8080
start "AutoRun Server" /min "%~dp0autorun.exe"
echo AutoRun 正在启动：http://localhost:%PORT%
echo 请从本文件或 autorun.exe 启动，不要只从 Windows PWA 图标启动。
echo 关闭最后一个 AutoRun 页面后，后端会自动退出。
