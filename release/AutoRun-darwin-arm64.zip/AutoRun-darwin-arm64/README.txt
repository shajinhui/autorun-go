AutoRun 本地版使用说明

一、Windows 用户

1. 解压 zip 后，双击 start-autorun.bat。
2. 程序会启动本地后端，并自动打开 http://localhost:8080。
3. 如果你安装过 Windows PWA 图标，不要只从 PWA 图标启动。
   PWA 只是浏览器应用，不能自己拉起本地后端。
4. 如果 PWA 页面提示“本地服务未启动”，请回到本文件所在目录，
   双击 start-autorun.bat 或 autorun.exe。

二、macOS 用户

1. 双击 start-autorun.command。
2. 如果系统提示无法打开，可以在终端运行 ./start-autorun.sh。

三、Linux 用户

在终端运行：

  ./start-autorun.sh

四、关闭方式

关闭最后一个 AutoRun 浏览器页面后，后端会自动退出。
如果你是从终端启动，也可以按 Ctrl+C 停止。

五、账号说明

手机号和密码在网页里输入。本地版不需要 Postgres、Redis 或云端数据库。
登录态和定时配置只保存在当前电脑的本地用户配置目录中。
