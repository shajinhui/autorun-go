@echo off
setlocal
cd /d "%~dp0"
if "%PORT%"=="" set PORT=8080
start "AutoRun Server" /min "%~dp0autorun.exe"
echo AutoRun started at http://localhost:%PORT%
echo Close the "AutoRun Server" window to stop the service.
